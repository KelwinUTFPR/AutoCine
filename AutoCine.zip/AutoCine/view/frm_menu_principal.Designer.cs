﻿namespace AutoCine.view
{
    partial class frm_menu_principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.foto5 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.titulo4 = new System.Windows.Forms.Label();
            this.foto4 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.titulo3 = new System.Windows.Forms.Label();
            this.foto3 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.titulo2 = new System.Windows.Forms.Label();
            this.foto2 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.foto1 = new System.Windows.Forms.PictureBox();
            this.titulo1 = new System.Windows.Forms.Label();
            this.titulo5 = new System.Windows.Forms.Label();
            this.titulo6 = new System.Windows.Forms.Label();
            this.foto6 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.Admin = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.foto5)).BeginInit();
            this.tableLayoutPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.foto4)).BeginInit();
            this.tableLayoutPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.foto3)).BeginInit();
            this.tableLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.foto2)).BeginInit();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.foto1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foto6)).BeginInit();
            this.tableLayoutPanel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1368, 857);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(116)))), ((int)(((byte)(166)))));
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.Admin, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1368, 50);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel9, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel8, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel7, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel6, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel5, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 100);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0, 30, 0, 10);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1710, 959);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 3;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.00001F));
            this.tableLayoutPanel8.Controls.Add(this.foto5, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.titulo5, 1, 1);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(456, 373);
            this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(456, 354);
            this.tableLayoutPanel8.TabIndex = 4;
            // 
            // foto5
            // 
            this.foto5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.foto5.Location = new System.Drawing.Point(102, 0);
            this.foto5.Margin = new System.Windows.Forms.Padding(0);
            this.foto5.Name = "foto5";
            this.foto5.Size = new System.Drawing.Size(250, 294);
            this.foto5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.foto5.TabIndex = 1;
            this.foto5.TabStop = false;
            this.foto5.Click += new System.EventHandler(this.foto5_Click);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 3;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.00001F));
            this.tableLayoutPanel7.Controls.Add(this.titulo4, 1, 1);
            this.tableLayoutPanel7.Controls.Add(this.foto4, 1, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(0, 373);
            this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(456, 354);
            this.tableLayoutPanel7.TabIndex = 3;
            // 
            // titulo4
            // 
            this.titulo4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.titulo4.AutoSize = true;
            this.titulo4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titulo4.Location = new System.Drawing.Point(105, 294);
            this.titulo4.Name = "titulo4";
            this.titulo4.Size = new System.Drawing.Size(244, 60);
            this.titulo4.TabIndex = 5;
            this.titulo4.Text = ".";
            this.titulo4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.titulo4.Click += new System.EventHandler(this.titulo4_Click);
            // 
            // foto4
            // 
            this.foto4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.foto4.Location = new System.Drawing.Point(102, 0);
            this.foto4.Margin = new System.Windows.Forms.Padding(0);
            this.foto4.Name = "foto4";
            this.foto4.Size = new System.Drawing.Size(250, 294);
            this.foto4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.foto4.TabIndex = 1;
            this.foto4.TabStop = false;
            this.foto4.Click += new System.EventHandler(this.foto4_Click);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 3;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.00001F));
            this.tableLayoutPanel6.Controls.Add(this.titulo3, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.foto3, 1, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(912, 20);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(456, 333);
            this.tableLayoutPanel6.TabIndex = 2;
            // 
            // titulo3
            // 
            this.titulo3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.titulo3.AutoSize = true;
            this.titulo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titulo3.Location = new System.Drawing.Point(105, 273);
            this.titulo3.Name = "titulo3";
            this.titulo3.Size = new System.Drawing.Size(244, 60);
            this.titulo3.TabIndex = 5;
            this.titulo3.Text = ".";
            this.titulo3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.titulo3.Click += new System.EventHandler(this.titulo3_Click);
            // 
            // foto3
            // 
            this.foto3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.foto3.Location = new System.Drawing.Point(102, 0);
            this.foto3.Margin = new System.Windows.Forms.Padding(0);
            this.foto3.Name = "foto3";
            this.foto3.Size = new System.Drawing.Size(250, 273);
            this.foto3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.foto3.TabIndex = 1;
            this.foto3.TabStop = false;
            this.foto3.Click += new System.EventHandler(this.foto3_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 3;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.00001F));
            this.tableLayoutPanel5.Controls.Add(this.titulo2, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.foto2, 1, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(456, 20);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(456, 333);
            this.tableLayoutPanel5.TabIndex = 1;
            // 
            // titulo2
            // 
            this.titulo2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.titulo2.AutoSize = true;
            this.titulo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titulo2.Location = new System.Drawing.Point(105, 273);
            this.titulo2.Name = "titulo2";
            this.titulo2.Size = new System.Drawing.Size(244, 60);
            this.titulo2.TabIndex = 5;
            this.titulo2.Text = ".";
            this.titulo2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.titulo2.Click += new System.EventHandler(this.titulo2_Click);
            // 
            // foto2
            // 
            this.foto2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.foto2.Location = new System.Drawing.Point(102, 0);
            this.foto2.Margin = new System.Windows.Forms.Padding(0);
            this.foto2.Name = "foto2";
            this.foto2.Size = new System.Drawing.Size(250, 273);
            this.foto2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.foto2.TabIndex = 1;
            this.foto2.TabStop = false;
            this.foto2.Click += new System.EventHandler(this.foto2_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.00001F));
            this.tableLayoutPanel4.Controls.Add(this.foto1, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.titulo1, 1, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 20);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(456, 333);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // foto1
            // 
            this.foto1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.foto1.Location = new System.Drawing.Point(102, 0);
            this.foto1.Margin = new System.Windows.Forms.Padding(0);
            this.foto1.Name = "foto1";
            this.foto1.Size = new System.Drawing.Size(250, 273);
            this.foto1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.foto1.TabIndex = 0;
            this.foto1.TabStop = false;
            this.foto1.Click += new System.EventHandler(this.foto1_Click);
            // 
            // titulo1
            // 
            this.titulo1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.titulo1.AutoSize = true;
            this.titulo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titulo1.Location = new System.Drawing.Point(105, 273);
            this.titulo1.Name = "titulo1";
            this.titulo1.Size = new System.Drawing.Size(244, 60);
            this.titulo1.TabIndex = 1;
            this.titulo1.Text = ".";
            this.titulo1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.titulo1.Click += new System.EventHandler(this.titulo1_Click);
            // 
            // titulo5
            // 
            this.titulo5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.titulo5.AutoSize = true;
            this.titulo5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titulo5.Location = new System.Drawing.Point(105, 294);
            this.titulo5.Name = "titulo5";
            this.titulo5.Size = new System.Drawing.Size(244, 60);
            this.titulo5.TabIndex = 5;
            this.titulo5.Text = ".";
            this.titulo5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.titulo5.Click += new System.EventHandler(this.titulo5_Click);
            // 
            // titulo6
            // 
            this.titulo6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.titulo6.AutoSize = true;
            this.titulo6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titulo6.Location = new System.Drawing.Point(105, 294);
            this.titulo6.Name = "titulo6";
            this.titulo6.Size = new System.Drawing.Size(244, 60);
            this.titulo6.TabIndex = 5;
            this.titulo6.Text = ".";
            this.titulo6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.titulo6.Click += new System.EventHandler(this.titulo6_Click);
            // 
            // foto6
            // 
            this.foto6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.foto6.Location = new System.Drawing.Point(102, 0);
            this.foto6.Margin = new System.Windows.Forms.Padding(0);
            this.foto6.Name = "foto6";
            this.foto6.Size = new System.Drawing.Size(250, 294);
            this.foto6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.foto6.TabIndex = 1;
            this.foto6.TabStop = false;
            this.foto6.Click += new System.EventHandler(this.foto6_Click);
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 3;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.00001F));
            this.tableLayoutPanel9.Controls.Add(this.foto6, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.titulo6, 1, 1);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(912, 373);
            this.tableLayoutPanel9.Margin = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 2;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(456, 354);
            this.tableLayoutPanel9.TabIndex = 5;
            // 
            // Admin
            // 
            this.Admin.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Admin.AutoSize = true;
            this.Admin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Admin.Location = new System.Drawing.Point(1309, 0);
            this.Admin.Name = "Admin";
            this.Admin.Size = new System.Drawing.Size(56, 50);
            this.Admin.TabIndex = 0;
            this.Admin.Text = "Admin";
            this.Admin.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frm_menu_principal
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(55)))), ((int)(((byte)(71)))));
            this.ClientSize = new System.Drawing.Size(1368, 857);
            this.Controls.Add(this.tableLayoutPanel1);
            this.ForeColor = System.Drawing.Color.Cornsilk;
            this.Name = "frm_menu_principal";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_menu_principal_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.foto5)).EndInit();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.foto4)).EndInit();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.foto3)).EndInit();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.foto2)).EndInit();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.foto1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foto6)).EndInit();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.PictureBox foto1;
        private System.Windows.Forms.Label titulo1;
        private System.Windows.Forms.PictureBox foto2;
        private System.Windows.Forms.PictureBox foto3;
        private System.Windows.Forms.Label titulo2;
        private System.Windows.Forms.PictureBox foto5;
        private System.Windows.Forms.Label titulo4;
        private System.Windows.Forms.PictureBox foto4;
        private System.Windows.Forms.Label titulo3;
        private System.Windows.Forms.Label titulo5;
        private System.Windows.Forms.Label Admin;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.PictureBox foto6;
        private System.Windows.Forms.Label titulo6;
    }
}